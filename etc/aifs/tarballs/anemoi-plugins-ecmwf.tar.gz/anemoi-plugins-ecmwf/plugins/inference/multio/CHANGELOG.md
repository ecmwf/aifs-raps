# Changelog

## 0.1.0 (2025-06-27)


### Features

* Multio Plugin ([#1](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/1)) ([46d434a](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/46d434aa3028a6dffb54c89f6facbe801d95deae))


### Bug Fixes

* **inference-multio:** Enable ensembles ([#10](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/10)) ([d29b7d3](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/d29b7d37aa4387dc8871b6d9d43e93ff900bfa5a))
