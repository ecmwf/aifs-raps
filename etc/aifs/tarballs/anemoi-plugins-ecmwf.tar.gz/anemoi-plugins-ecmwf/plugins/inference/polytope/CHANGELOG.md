# Changelog

## 0.1.0 (2025-06-16)


### Features

* Add Polytope plugin ([#2](https://github.com/ecmwf/anemoi-plugins-ecmwf/issues/2)) ([17045cb](https://github.com/ecmwf/anemoi-plugins-ecmwf/commit/17045cb012cc17f77a5b8426d576665251908293))
